package com.example.mysimplecleanarchitecture.domain

interface ImessageRepository {
    fun getWelcomeMessage(name: String): MessageEntity
}