package com.example.mysimplecleanarchitecture.domain

data class MessageEntity(
    var welcomeMessage: String
)