package com.example.mysimplecleanarchitecture.domain

class MessageInteractor(private val messageRepository: ImessageRepository): MessageUseCase {
    override fun getMessage(name: String): MessageEntity {
        return messageRepository.getWelcomeMessage(name)
    }
}