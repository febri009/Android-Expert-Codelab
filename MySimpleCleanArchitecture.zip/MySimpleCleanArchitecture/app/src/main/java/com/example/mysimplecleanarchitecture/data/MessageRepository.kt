package com.example.mysimplecleanarchitecture.data

import com.example.mysimplecleanarchitecture.domain.ImessageRepository
import com.example.mysimplecleanarchitecture.domain.MessageEntity

class MessageRepository(private val messageDataSource: IMessageDataSource): ImessageRepository {
    override fun getWelcomeMessage(name: String) = messageDataSource.getMessageFromSource(name)
}